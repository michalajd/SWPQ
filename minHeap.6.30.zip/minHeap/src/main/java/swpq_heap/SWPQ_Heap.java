/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swpq_heap;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import swpq_heap.SWPQ_Element;

/**
 *
 * @author dennismj
 */
public class SWPQ_Heap {
    static final int MINHEAP = 128;
    private SWPQ_Element heap [] = new SWPQ_Element[MINHEAP];
    private int heap_size = 0;
    
    public int parent(int i) {
        assert (i >= 1);
        return i/2;
    }
    
    public int left(int i) {
        int lc = 2*i;
        return (lc);
    }
    
    public int right(int i) {
        int rc = 2*i +1;
        return (rc);
    }
    
    public void minHeapify(int i) {
        int l, r, smallest;
        //System.out.println("heapify(" + i + ")";
        l = left(i);
        r = right(i);
        if ((l <= heap_size) && (heap[l].getKey() < heap[i].getKey())) {
            smallest = l;
        } else {
            smallest = i;
        }
        if ((r <= heap_size) && (heap[r].getKey() < heap[smallest].getKey())) {
            smallest = r;
        }
        if (smallest != i) {
            //System.out.println("swapping " + i + ":" + heap[i] + " " + smallest + ":" + heap[smallest]);
            SWPQ_Element tmp;
            tmp = heap[i];
            heap[i] = heap[smallest];
            heap[smallest] = tmp;
            minHeapify(smallest);
        }
    }
    
    public SWPQ_Element minimum() {
        return heap[1];
    }
    
    public void decreaseKey(int i, int key) {
        if (key < heap[i].getKey()) {
            System.out.println("Error: heap_increase_key new_key " + key + "smaller than current key " + heap[i].getKey());
            return;
        }
        heap[i].setKey(key);
        while((i > 1) && heap[parent(i)].getKey() > heap[i].getKey()) {
            SWPQ_Element temp;
            temp = heap[i];
            heap[i] = heap[parent(i)];
            heap[parent(i)] = temp;
            i = parent(i);
        }
    }
    
    public void minHeapInsert(int key, int val) {
        if (heap_size >= MINHEAP) {
            System.out.println("Error: maximum heap size reached!");
            return;
        }
        heap_size ++;
        heap[heap_size] = new SWPQ_Element(Integer.MIN_VALUE, val);
        decreaseKey(heap_size, key);
        }
    
    SWPQ_Element extractMin() {
        if (heap_size < 1) {
            System.out.println("Error: extract from empty heap!");
            return null;
        }
        SWPQ_Element emax = heap[1];
        heap[1] = heap[heap_size];
        heap_size--;
        minHeapify(1);
        return emax; 
    }
    
    public void printHeap() {
      System.out.print("Heap Array size=");
      System.out.println(heap_size);
      for (int i=1; i <= heap_size; i++) {
          System.out.print(" "  + heap[i]);
      }
      System.out.println();
    }
    
    public void printTree() {
        // use blank println lines to create proper spacing
        System.out.println(" ");
        for (int i=1; i<= 1; i++) {
            System.out.print("           " + heap[i]);
        }
        System.out.println(" ");
        for (int j = 2; j <= 3; j++) {
            System.out.print("   " + heap[j] + "      ");
        }
        System.out.println(" ");
        for (int k = 4; k <= 6; k++) {
            System.out.print(heap[k] + "  ");
        }
        System.out.println(" ");
    }
    
    public static void main(String[] args) {
        SWPQ_Heap h = new SWPQ_Heap();
        h.minHeapInsert(5, 10);
        h.printHeap();
        h.minHeapInsert(2, 100);
        h.printHeap();
        h.minHeapInsert(18, 30);
        h.printHeap();
        h.minHeapInsert(36, 0);
        h.printHeap();
        h.minHeapInsert(12, 5);
        h.printHeap();
        h.minHeapInsert(7, 11);
        h.printHeap();
        // display text tree
        h.printTree();
        //display drawing of tree
        JFrame frame = new DrawTreeFrame();
        frame.show();
        while (h.heap_size >=1) {
            SWPQ_Element e = h.extractMin();
            System.out.println("Removed " + e);
        }
        h.printHeap();
    }
} 
