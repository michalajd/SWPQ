/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class FirstFrame extends JFrame {
    public FirstFrame() {
        setTitle("FirstFrame");
        setSize(300, 200);
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        } );
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        int screenHeight = d.height;
        int screenWidth = d.width;
        setSize(screenWidth/2, screenHeight/2);
        setLocation(screenWidth/4, screenHeight/4);
        Image img = tk.getImage("icon.gif");
        setIconImage(img);
        Container contentPane = getContentPane();
        //contentPane.add(new NotHelloWorldPanel());
        contentPane.add(new NotHelloWorldPanel2());
    }
}
