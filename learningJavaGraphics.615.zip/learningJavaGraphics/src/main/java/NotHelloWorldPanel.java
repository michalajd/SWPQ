/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class NotHelloWorldPanel extends JPanel {
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Font f = new Font("SansSerif", Font.BOLD, 14);
        g.setFont(f);
        g.drawString("Not a Hello, World program", 75, 100);
        Font v = new Font("Dialog", Font.PLAIN, 20);
        g.setFont(v);
        g.drawString("\u2297", 300, 300);
    }
}
