/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DrawTreeFrame extends JFrame {
    public DrawTreeFrame() {
        setTitle("HeapTree");
        setSize(600, 600);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        } );
        
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        int screenHeight = d.height;
        int screenWidth = d.width;
        //setLocation(screenWidth/4, screenHeight/4);
        //setSize(screenWidth/2, screenHeight/2);
        Container contentPane = getContentPane();
        contentPane.add(new DisplayTreePanel());
    }
    
}
