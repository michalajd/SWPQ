package swpq_heap;

import javax.swing.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
class SWPQ_Tree extends JFrame {
    public FirstFrame() {
        setTitle("FirstFrame");
        setSize(300, 300);
    }
}
