package swpq_heap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class TreePanel extends JPanel {
    private Font f;
    private FontMetrics fm;
    
    public void setFonts(Graphics g) {
        if (f != null) return;
        f = new Font("Helvetica", Font.PLAIN, 18);
        fm = g.getFontMetrics(f);
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int[] heap = { 36, 18, 7, 2, 12, 5 };
        setFonts(g);
        int r = 50; // size of the radius of each circle
        int window = 600; //size of the window
        
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension d = tk.getScreenSize();
        int screenHeight = d.height;
        int screenWidth = d.width;
        
        for (int i = 0; i <= 0; i++) {
            g.setColor(Color.white);
            g.fillOval(window/2-r/2, window/6, r, r);
            g.setColor(Color.black);
            g.drawOval(window/2-r/2, window/6, r, r);
            g.setFont(f);
            g.drawString("   " + heap[i], window/2-r/2, window/6+r/2);
            g.drawLine(window/2, window/6+r, window/3, window/3+r/2);
            g.drawLine(window/2, window/6+r, 2*window/3, window/3+r/2);
        }
        
        for(int i = 1; i <= 1; i++) {
            g.setColor(Color.white);
            g.fillOval(window/3-r, window/3, r, r);
            g.setColor(Color.black);
            g.drawOval(window/3-r, window/3, r, r);
            g.drawString("   " + heap[i], window/3-r, window/3+r/2);
            g.drawLine(window/3-r/2, window/3+r, window/4-r/2, 2*window/4);
            g.drawLine(window/3-r/2, window/3+r, 2*window/4-r*3/2, 2*window/4);
        }
        
        for(int i = 2; i <= 2; i++) {
            g.setColor(Color.white);
            g.fillOval(2*window/3, window/3, r, r);
            g.setColor(Color.black);
            g.drawOval(2*window/3, window/3, r, r);
            g.drawString("    " + heap[i], 2*window/3, window/3+r/2);
            g.drawLine(2*window/3+r/2, window/3+r, 9/4*window/4+r*3/2, 2*window/4);
        }
        
        for(int i = 3; i <= 3; i++) {
            g.setColor(Color.white);
            g.fillOval(window/4-r-r/2, 2*window/4-r/2, r, r);
            g.setColor(Color.black);
            g.drawOval(window/4-r-r/2, 2*window/4-r/2, r, r);
            g.drawString("    " + heap[i], window/4-r-r/2, 2*window/4);
        }
        
        for(int i = 4; i <= 4; i++) {
            g.setColor(Color.white);
            g.fillOval(2*window/4-r*3/2, 2*window/4-r/2, r, r);
            g.setColor(Color.black);
            g.drawOval(2*window/4-r*3/2, 2*window/4-r/2, r, r);
            g.drawString("   " + heap[i], 2*window/4-r*3/2, 2*window/4);
        }
        
        for(int i = 5; i <= 5; i++) {
            g.setColor(Color.white);
            g.fillOval(9/4*window/4+r*1/2, 2*window/4-r/2, r, r);
            g.setColor(Color.black);
            g.drawOval(9/4*window/4+r*1/2, 2*window/4-r/2, r, r);
            g.drawString("    " + heap[i], 9/4*window/4+r*1/2, 2*window/4);
        }
    }
    
}
