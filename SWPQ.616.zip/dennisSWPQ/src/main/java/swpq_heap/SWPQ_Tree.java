package swpq_heap;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
class SWPQ_Tree extends JFrame {
    public SWPQ_Tree() {
        setTitle("GraphicsTree");
        setSize(600, 600);
        addWindowListener(new WindowAdapter () {
            public void WindowClosing(WindowEvent e) {
                System.exit(0);
            }
        } );
        Container contentPane = getContentPane();
        contentPane.add(new TreePanel());
    }
}
