/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ImagePanel extends JPanel {
    private Image image;
    public ImagePanel() {
        image = Toolkit.getDefaultToolkit().getImage("blue-ball.gif");
        MediaTracker tracker = new MediaTracker(this);
        tracker.addImage(image, 0);
        try { tracker.waitForID(0); }
        catch (InterruptedException e) {}
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension d = getSize();
        int clientWidth = d.width;
        int clientHeight = d.height;
        
        int imageWidth = image.getWidth(this);
        int imageHeight = image.getHeight(this);
        
        g.drawImage(image, 0, 0, this);
        for (int i = 0; i * imageWidth <= clientWidth; i++) {
            for (int j = 0; j * imageHeight <= clientHeight; j++) {
                if (i + j > 0) {
                    g.copyArea(0, 0, imageWidth, imageHeight, i*imageWidth, j*imageHeight);
                }
            }
        }
    }
}
