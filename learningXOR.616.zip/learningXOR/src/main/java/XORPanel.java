/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class XORPanel extends JPanel {
    XORPanel() {
        setBackground(Color.black);
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.red);
        g.fillRect(10, 10, 80, 30);
        g.setColor(Color.green);
        g.fillRect(50, 20, 80, 30);
        g.setColor(Color.blue);
        g.fillRect(130, 40, 80, 30);
        g.setXORMode(Color.pink);
        g.fillRect(90, 30, 80, 30);
    }

}
