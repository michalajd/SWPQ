/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

public class DrawPolyMain {
    public static void main(String[] args) {
        JFrame frame = new DrawPolyFrame();
        frame.show();
        JFrame frame2 = new DrawRectPanel();
        frame2.show();
    }
    
}
