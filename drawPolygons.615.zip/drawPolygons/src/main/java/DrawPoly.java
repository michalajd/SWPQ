/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DrawPolyPanel extends JPanel {
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int r = 40; // radius of circle component of Pac-Man
        int cx = 50; // center of that circle
        int cy = 100;
        int angle = 30; // opening angle of mouth
        
        int dx = (int)(r * Math.cos(angle * Math.PI / 180));
        int dy = (int)(r * Math.sin(angle * Math.PI / 180));
        
        g.drawLine(cx, cy, cx+dx, cy+dy); // lower jaw
        g.drawLine(cx, cy, cx+dx, cy-dy); // upper jaw
        g.drawArc(cx-r, cy-r, 2*r, 2*r, angle, 360-2*angle);
        
        Polygon p = new Polygon();
        cx = 150;
        for (int i = 0; i < 5; i++) {
            p.addPoint((int)(cx+r * Math.cos(i*2*Math.PI/5)), (int)(cy+r * Math.sin(i*2*Math.PI/5)));
        }
        g.drawPolygon(p);
        
        Polygon s = new Polygon();
        cx = 250;
        for(int i = 0; i < 360; i++){
            double t = i/360.0;
            s.addPoint((int)(cx+r*t*Math.cos(8*t*Math.PI)), (int)(cy+r*t*Math.sin(8*t*Math.PI)));
        }
        g.drawPolygon(s);
    }
    
}
