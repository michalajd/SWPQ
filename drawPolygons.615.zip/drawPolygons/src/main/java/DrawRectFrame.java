/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

class DrawRectFrame extends JPanel {
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.blue);
        g.drawRect(10, 10, 80, 30);
        g.drawRoundRect(100, 10, 80, 30, 15, 15);
        int thickness = 4;
        
        for (int i = 0; i <= thickness; i++) {
            g.draw3DRect(200-i, 10-i, 80+2*i, 30+2*i, true);
        }
        for (int i = 0; i < thickness; i++) {
            g.draw3DRect(200-i, 50-i, 80+2*i, 30+2*i, false);
        }
        g.drawOval(10, 100, 80, 30);
    }
    
}
