/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dennismj
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DrawPolyFrame extends JFrame {
    public DrawPolyFrame() {
        setTitle("DrawPoly");
        setSize(300, 200);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        } );
        Container contentPane = getContentPane();
        contentPane.add(new DrawPolyPanel());
    }
    
}
